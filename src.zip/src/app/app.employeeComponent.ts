import { Component } from '@angular/core';
@Component({
  selector: 'my-component',
templateUrl: `./app.employeeComponent.html`,
})
export class EmployeeComponent{
     
	 emp:any[]=[
	 {empId:10,empName:"varun",empSal:10000},
	 {empId:10,
	 empName:"varun",
	 empSal:10000},
	 {empId:10,
	 empName:"varun",
	 empSal:10000}
	 ];
	 
}
//<h1>{{empName}} is a name and empid is {{empId}} and salary is {{empSal}}</h1>